<?php
require_once('resource/php/class/edit.php');

if(!empty($_GET['id'])){
    $edit = new edit($_GET['id']);
    $edit->editTask();
    header('Location:index.php');
  }
  else
  {
    header('Location:index.php');
  }

  ?>