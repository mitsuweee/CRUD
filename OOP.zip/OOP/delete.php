<?php

require_once('resource/php/class/delete.php');
if(!empty($_GET['id'])){
    $delete = new delete($_GET['id']);
    $delete->deleteTask();
    header('Location:index.php');
  }else{
    header('Location:index.php');
  }
?>